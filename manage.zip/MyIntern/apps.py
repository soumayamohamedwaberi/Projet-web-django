from django.apps import AppConfig


class MyinternConfig(AppConfig):
    name = 'MyIntern'
